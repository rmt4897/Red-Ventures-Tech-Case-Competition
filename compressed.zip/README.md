# Red-Ventures-Tech-Case-Competition
By Abhay Zala, David Lu, & Michael Tyndall
INITIAL COMMIT! 
